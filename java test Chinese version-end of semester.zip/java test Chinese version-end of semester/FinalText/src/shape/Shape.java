package shape;

public abstract class Shape {
	
	abstract public double Area();
}
